"""major_changes.md - a running, human-readable log of every change the agent makes.

write_file / edit_file call append_change() automatically. log_change() is for changes made
some other way (e.g. through an MCP tool). The file lives at
<folder>/.agent_context/major_changes.md
"""
from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Annotated

from agent_framework import tool
from pydantic import Field

_HEADER = ("# Major changes\n\nNewest entries at the bottom. Written by the agent; "
           "each entry = one change.\n\n")
_LOCKS: dict[str, asyncio.Lock] = {}


def log_path(ctx):
    return ctx.context_dir / "major_changes.md"


def _fmt(items) -> str:
    return ", ".join(f"`{i}`" for i in items) if items else "_none identified_"


async def append_change(ctx, summary: str, files: list[str], affected: list[str] | None,
                        reason: str = "") -> None:
    path = log_path(ctx)
    conv = getattr(ctx, "conv", None)
    who = f"{conv.name} / {ctx.model_name}" if conv is not None else (ctx.model_name or "agent")
    lines = [
        f"## {datetime.now():%Y-%m-%d %H:%M}",
        f"- **Change:** {summary.strip()}",
        f"- **Files changed:** {_fmt(files)}",
        f"- **Directly affected (files / processes):** {_fmt(affected or [])}",
    ]
    if reason.strip():
        lines.append(f"- **Why:** {reason.strip()}")
    lines += [f"- **By:** {who}", "", ""]
    text = "\n".join(lines)

    def _write() -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        new = not path.exists()
        with path.open("a", encoding="utf-8") as f:
            if new:
                f.write(_HEADER)
            f.write(text)

    lock = _LOCKS.setdefault(str(path), asyncio.Lock())
    async with lock:                       # parallel tool calls must not interleave entries
        await asyncio.to_thread(_write)


def build_tools(ctx) -> list:
    @tool(approval_mode="never_require")
    async def log_change(
        summary: Annotated[str, Field(description="Brief description of the change (1-2 sentences).")],
        files_changed: Annotated[list[str], Field(description="Files or resources changed.")],
        affected: Annotated[list[str] | None, Field(
            description="Files, modules or processes directly affected by this change.")] = None,
        reason: Annotated[str, Field(description="Why - e.g. the user-approved decision.")] = "",
    ) -> str:
        """Record a change made by some means OTHER than write_file/edit_file (those log
        automatically) - for example a change made through an MCP tool."""
        await append_change(ctx, summary, files_changed, affected, reason)
        ctx.say("major_changes.md updated")
        return "Logged in major_changes.md."

    return [log_change]
