"""write_file / edit_file (project mode only).

Every call
  1. must say what changed and what it directly affects (change_summary / affected),
  2. shows YOU a diff and waits for approval (config: changes.confirm_writes),
  3. is appended to major_changes.md.
Rejections go back to the model together with your note, so it can adapt.
"""
from __future__ import annotations

import asyncio
import difflib
import uuid
from pathlib import Path
from typing import Annotated

from agent_framework import tool
from pydantic import Field

from tools._paths import resolve_in_project
from tools.changes import append_change

_PATH_LOCKS: dict[str, asyncio.Lock] = {}
MAX_DIFF_LINES = 120


def _diff(rel: str, old: str, new: str, is_new: bool) -> str:
    if is_new:
        lines = new.splitlines()
        head = [f"+{l}" for l in lines[:60]]
        if len(lines) > 60:
            head.append(f"... (+{len(lines) - 60} more lines)")
        return "\n".join(head) or "(empty file)"
    d = list(difflib.unified_diff(old.splitlines(), new.splitlines(),
                                  f"a/{rel}", f"b/{rel}", lineterm="", n=2))
    if len(d) > MAX_DIFF_LINES:
        d = d[:MAX_DIFF_LINES] + [f"... ({len(d) - MAX_DIFF_LINES} more diff lines)"]
    return "\n".join(d)


def _atomic_write(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(f"{p.name}.{uuid.uuid4().hex[:6]}.tmp")
    tmp.write_text(text, encoding="utf-8", newline="")
    tmp.replace(p)


def build_tools(ctx) -> list:
    if ctx.project_root is None:
        return []
    confirm = ctx.config.get("changes", {}).get("confirm_writes", True)

    async def _apply(p: Path, rel: str, old: str, new: str, is_new: bool, summary: str,
                     affected: list[str] | None, reason: str, verb: str) -> str:
        if confirm and ctx.ui is not None:
            ok, note = await ctx.ui.confirm_change(rel, summary, _diff(rel, old, new, is_new),
                                                   is_new, affected or [])
            if not ok:
                return (f"REJECTED by the user - nothing was written. User note: "
                        f"{note or '(none)'}. Do not retry the same change; adapt or ask.")
        await asyncio.to_thread(_atomic_write, p, new)
        await append_change(ctx, summary, [f"{rel} ({verb})"], affected, reason)
        ctx.say(f"{verb}: {rel} (logged in major_changes.md)")
        return (f"{verb.capitalize()} {rel}. Logged in major_changes.md. "
                f"Affected files/processes should be re-checked: {', '.join(affected or []) or 'none listed'}.")

    @tool(approval_mode="never_require")
    async def write_file(
        path: Annotated[str, Field(description="File to create or fully overwrite, relative to the project root.")],
        content: Annotated[str, Field(description="Complete new file content.")],
        change_summary: Annotated[str, Field(description="Brief description of this change (1-2 sentences).")],
        affected: Annotated[list[str] | None, Field(
            description="Other files / modules / processes directly affected by this change.")] = None,
        reason: Annotated[str, Field(description="Why - reference the user-approved decision if any.")] = "",
    ) -> str:
        """Create a new file or overwrite an existing one. The user sees a diff and must approve.
        Prefer edit_file for small changes to existing files."""
        try:
            p = resolve_in_project(ctx, path, for_write=True)
        except ValueError as e:
            return f"Error: {e}"
        rel = p.relative_to(ctx.project_root.resolve()).as_posix()
        lock = _PATH_LOCKS.setdefault(str(p), asyncio.Lock())
        async with lock:
            existed = p.exists()
            if existed and not p.is_file():
                return f"Error: {rel} is not a file."
            old = (await asyncio.to_thread(p.read_text, "utf-8", "replace")) if existed else ""
            if existed and old == content:
                return "No change: the file already has exactly this content."
            return await _apply(p, rel, old, content, not existed, change_summary, affected,
                                reason, "overwrote" if existed else "created")

    @tool(approval_mode="never_require")
    async def edit_file(
        path: Annotated[str, Field(description="Existing file, relative to the project root.")],
        old_str: Annotated[str, Field(description="Exact text to replace. Must occur exactly once.")],
        new_str: Annotated[str, Field(description="Replacement text (may be empty to delete).")],
        change_summary: Annotated[str, Field(description="Brief description of this change (1-2 sentences).")],
        affected: Annotated[list[str] | None, Field(
            description="Other files / modules / processes directly affected by this change.")] = None,
        reason: Annotated[str, Field(description="Why - reference the user-approved decision if any.")] = "",
    ) -> str:
        """Replace one exact, unique snippet in an existing file. The user sees a diff and must approve."""
        try:
            p = resolve_in_project(ctx, path, for_write=True)
        except ValueError as e:
            return f"Error: {e}"
        if not p.is_file():
            return f"Error: file not found: {path}"
        rel = p.relative_to(ctx.project_root.resolve()).as_posix()
        lock = _PATH_LOCKS.setdefault(str(p), asyncio.Lock())
        async with lock:
            old = await asyncio.to_thread(p.read_text, "utf-8", "replace")
            n = old.count(old_str)
            if n != 1:
                return (f"Error: old_str occurs {n} times in {rel} (must be exactly 1). "
                        "Add surrounding context to make it unique." if n else
                        f"Error: old_str not found in {rel}. Re-read the file; it may have changed.")
            return await _apply(p, rel, old, old.replace(old_str, new_str, 1), False,
                                change_summary, affected, reason, "edited")

    return [write_file, edit_file]
