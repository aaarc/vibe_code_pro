# MAF Agent

A command-line coding/research assistant built on the [Microsoft Agent Framework](https://learn.microsoft.com/en-us/agent-framework/) (Python). It streams replies with live tool-call status, asks you before major decisions (and pushes back on flawed ones), reads project folders with optional parallel sub-agents, logs every change it makes, loads Agent Skills and MCP servers, and hands the conversation from one LLM to the next when a model reaches its output-token limit.

- **Models (in handoff order):** Claude Opus 4.5, then Claude Sonnet 4.5, then GPT-4o-mini (all configurable)
- **Framework:** `agent-framework==1.18.0`
- **Interface:** terminal only (pure Python, [`rich`](https://github.com/Textualize/rich) for output)

## Features

- **Two modes:** open a project folder, or just chat.
- **Persistent, resumable conversations** per folder. Name them, rename them, delete them, start new ones, or resume old ones.
- **Short context by design:** each conversation keeps a rolling summary plus the last few messages, not the full transcript.
- **Handoff between models** when a model reaches 70,000 output tokens, with a running token count after every reply.
- **Streaming with live status:** text streams as markdown; you see `>> calling web_search`, `waiting for read_file, web_search...`, `<< web_search ok (1.2s)`, and tagged progress lines from sub-agents.
- **Decision checkpoints:** before major decisions the agent shows options with pros/cons and a recommendation, quizzes you, and critiques your answer before acting.
- **Sub-agents and debate mode** for parallel project exploration and contested choices; each needs your approval and respects a cap you set.
- **`major_changes.md`:** every file change is logged with a brief summary, the files changed, and the files/processes directly affected.
- **Approval for every file change** (diff shown) before anything is written.
- **Tools** loaded automatically from `tools/`: web search, directory listing, chunked file reading with `.md` notes, file writing/editing, change logging, decisions, sub-agents.
- **Parallel tool calling:** independent tool calls in one step run concurrently.
- **Agent Skills** from `skills/` (folders containing `SKILL.md`).
- **MCP servers** from `mcp_json.json` (stdio and streamable HTTP).

## Quick start

Requires Python 3.11 or newer.

```bash
pip install -r requirements.txt
cp .env.example .env        # then add your API keys
python main.py
```

`.env`:

```
ANTHROPIC_API_KEY=...
OPENAI_API_KEY=...
```

A model whose key is missing is skipped in the handoff chain (the app tells you at startup). You need at least one key.

## Using it

On start you get a menu:

```
1) Open a project folder
2) Just chat
q) Quit
```

- **Open a project folder:** enter a path, or a number from the recent-projects list. State is stored in `<folder>/.agent_context/`.
- **Just chat:** no folder, no file tools. State is stored in `.agent_context/` next to `main.py`.

You then see the conversations for that location. Enter a number to open one, or:

| Input | Action |
|-------|--------|
| `n` | New conversation (optionally named) |
| `r<N>` | Rename conversation N (e.g. `r2`) |
| `d<N>` | Delete conversation N (asks for confirmation) |
| `b` | Back to the main menu |

### Chat commands

| Command | Action |
|---------|--------|
| `/new [name]` | Start a new conversation in this folder |
| `/rename <name>` | Rename the current conversation |
| `/switch` | Back to the conversation list |
| `/tokens` | Show token usage per model |
| `/handoff` | Manually hand off to the next model |
| `/subagents [n]` | Show or set the max sub-agents per batch for this conversation (`0` disables sub-agents and debate) |
| `/changes` | Show the tail of `major_changes.md` |
| `/menu` | Back to the main menu |
| `/quit` | Exit |
| `/help` | List commands |

After every reply you get a status line like:

```
turn in 3,210 / out 512 | claude-opus-4.5 12,345/70,000 out | claude-sonnet-4.5 0/70,000 out | gpt-4o-mini 0/70,000 out | total in 40,100 / out 12,345
```

## Project layout

```
maf_agent/
├── main.py              # CLI: menus, conversation picker, chat loop
├── config.json          # models, limits, context and tool settings
├── mcp_json.json        # MCP servers
├── .env.example
├── requirements.txt
├── agent_core/
│   ├── engine.py        # model chain, handoff, token accounting, summarising
│   ├── store.py         # .agent_context persistence
│   ├── ui.py            # streaming display, spinner, and all interactive prompts
│   ├── notes.py         # per-file .md note format
│   └── mcp.py           # MCP config loader
├── tools/               # every module exposing build_tools(ctx) is auto-loaded
│   ├── web_search.py
│   ├── file_reader.py   # list_directory, read_file, save_file_note
│   ├── file_writer.py   # write_file, edit_file (diff + approval + logging)
│   ├── changes.py       # major_changes.md, log_change
│   ├── decisions.py     # propose_decision
│   ├── subagents.py     # spawn_subagents, start_debate
│   ├── _context.py      # shared ToolContext (ignored by the loader)
│   └── _paths.py        # project-root path safety (ignored by the loader)
└── skills/
    └── code-review/SKILL.md
```

`agent_core/` contains no terminal I/O, so another front-end (Textual, NiceGUI, ...) can reuse it.

## What gets stored: `.agent_context/`

```
.agent_context/
├── conversations/<id>.json   # name, rolling summary, recent messages, token usage, handoff history
├── file_notes/<path>.md      # one short note per file the agent has read
├── major_changes.md          # running log of every change the agent made
└── recent_projects.json      # only in the app's own folder (recent folders list)
```

Keeping context short:

- Older messages are folded into a summary of at most about 250 words once the history grows past `recent_messages_kept + compact_slack` messages.
- Individual stored messages are clipped to `max_message_chars`.
- The agent receives a compact "Known files" digest built from the file notes, so it knows what it has already read.

You can delete `.agent_context/` at any time to reset a project. It is safe to add to `.gitignore`.

## Tools

| Tool | Available in | What it does |
|------|--------------|--------------|
| `web_search` | both modes | DuckDuckGo search via `ddgs` (no key needed). Returns title, URL, snippet. |
| `list_directory` | project mode | Lists a folder with approximate token sizes; marks files that already have a note with `[note]`. |
| `read_file` | project mode | Reads **one file per call**, up to `read_chunk_tokens` (default 100,000) tokens. Continue large files with `start_token`. Writes or updates the file's `.md` note. |
| `save_file_note` | project mode | Saves a short summary into the file's note for later turns and handoffs. |
| `write_file` / `edit_file` | project mode | Create/overwrite a file or replace one unique snippet. You see a diff and approve; the change is logged automatically. |
| `log_change` | both modes | Logs a change made some other way (e.g. through an MCP tool). |
| `propose_decision` | both modes | Asks you to decide: options, pros/cons, recommendation. |
| `spawn_subagents` | project mode | Approved, read-only parallel exploration. |
| `start_debate` | both modes | Approved debate between sub-agents; advisory only. |

Behaviours worth knowing:

- If a file is unchanged (SHA-256 match) and already has a summary, `read_file` returns the **saved note** instead of the raw text. Pass `force_reread=true` to get the raw content.
- File access is restricted to the project folder; binary files and files over `max_file_bytes` are refused.
- Token counting for chunking uses `tiktoken` (`o200k_base`). That is exact for OpenAI models and a close approximation for Claude.
- Parallel reads share a **per-turn read budget** (`read_budget` per model in `config.json`) so several large reads in one step cannot overflow the context window.

### Adding your own tool

Create `tools/my_tool.py`:

```python
from typing import Annotated
from agent_framework import tool
from pydantic import Field

def build_tools(ctx):
    @tool(approval_mode="never_require")
    async def my_tool(x: Annotated[str, Field(description="Input")]) -> str:
        """What the tool does (the model reads this)."""
        return x.upper()
    return [my_tool]
```

Use `async def` (and `asyncio.to_thread` for blocking work) so parallel calls really run concurrently. `ctx` gives you `config`, `context_dir`, and `project_root` (`None` in just-chat mode).

## Decision checkpoints

The agent's system prompt defines a *major decision*: choosing between approaches or architectures, adding/removing dependencies, changing interfaces or schemas, deleting/overwriting substantial code, or any open question with several reasonable answers. For those it calls `propose_decision`, which shows:

```
Decision needed: Session storage
  #  Option         Pros          Cons
  1  Signed cookies simple        size limits, no revocation
  2  Redis          revocable     needs infrastructure
Recommended: Redis - you need revocation.
Pick 1-2, c = your own approach, d = discuss / ask a question, s = stop >
```

- **Pick a number:** the agent proceeds, after a sanity check of your choice against the project and earlier decisions.
- **`c` (or just type text):** your own idea. The agent must critique it honestly and, if it finds flaws, explain them and ask again (with your idea included as an option) before doing anything.
- **`d`:** ask a question; the agent answers and re-asks.
- **`s`:** stop; nothing related proceeds.

Your decisions are saved per conversation (last 15, short) and passed to the next turn and to the next model after a handoff. This is enforced by instructions and tool results, not by code, so a model can still occasionally skip a checkpoint; the diff approval on file changes is the hard backstop.

## Sub-agents and debate

Both require your approval **every time** and respect your cap.

**Sub-agents** (`spawn_subagents`, project mode): the main agent splits broad exploration into tasks with disjoint paths. You see the plan (names, scopes, jobs, model) and answer `y`, `n`, or a number to run only the first N. Sub-agents run in parallel, are **read-only** (they can list and read files and write `.md` notes, nothing else), each get their own read budget (`subagents.read_budget`), and return short findings to the main agent. Their notes appear in `.agent_context/file_notes/` like any other.

**Debate** (`start_debate`, both modes): 2-3 debaters each argue one position for 1-3 rounds, rebutting each other; a judge then gives a verdict. You see every round and the verdict. Debaters can't read files or change anything (the main agent passes them the facts), and the result is advice only: the main agent then takes it to you with `propose_decision`.

**The cap:** `/subagents N` sets the maximum number of sub-agents in one batch (default `subagents.default_max`, 4). A request above the cap is refused and the agent must re-plan; a debate needs one sub-agent per position. `/subagents 0` disables both. The cap is stored per conversation. Because every batch needs your approval, you also control the total.

Sub-agents and debate use `subagents.model` (default `gpt-4o-mini`) while it has budget, otherwise the active model. **Their tokens count against that model's `output_limit`**, as do summariser tokens, so heavy use can use up the budget of your last fallback model; raise its `output_limit` or pick a different `subagents.model`.

## Change log: `major_changes.md`

Every `write_file`/`edit_file` call must include a `change_summary`, the other files/processes it directly `affected`, and optionally a `reason`. After you approve the diff, the entry is appended to `.agent_context/major_changes.md`:

```markdown
## 2026-10-29 20:46
- **Change:** Move session storage from cookies to Redis
- **Files changed:** `src/session.py (edited)`, `requirements.txt (edited)`
- **Directly affected (files / processes):** `src/login.py`, `deploy process (needs a Redis instance)`
- **Why:** User chose Redis over signed cookies
- **By:** Auth refactor / claude-opus-4.5
```

Rejected changes are not written or logged; your note goes back to the model. Changes made through MCP tools are logged only if the model calls `log_change`. View the log with `/changes`. Set `"changes": {"confirm_writes": false}` in `config.json` to skip the approval prompt (logging stays on).

## Streaming and status

Replies stream live and render as markdown. During a turn you will see lines like:

```
assistant (claude-opus-4.5)
>> calling web_search
>> calling read_file
   web_search: python asyncio gather
   read_file: src/app.py
<< web_search ok (1.4s)
<< read_file ok (0.2s)
```

A spinner shows what it is waiting for (`waiting for read_file, web_search...` or `waiting for claude-opus-4.5...`). Sub-agent lines are tagged `[name]`. Interactive prompts pause the spinner and resume it afterwards; if several prompts arrive at once (parallel tool calls) they are asked one at a time.

## Model handoff

- Output tokens are counted **per model, per conversation** and saved with the conversation.
- The active model is the first one in `config.json` that is not retired and is under its `output_limit`.
- When a turn pushes the active model over its limit, the engine summarises the conversation, records a handoff note, and the next turn runs on the next model. The new model receives the summary, the last couple of messages, and the handoff note.
- The limit is checked between turns, so a model can overshoot slightly; a reply is never cut off mid-way.
- Tokens used by the summariser and by sub-agents/debaters are counted against the model that produced them.
- When every model is exhausted you are told to use `/new`. A new conversation resets the counters; file notes are kept.

## Configuration: `config.json`

```json
{
  "models": [
    {"name": "claude-opus-4.5", "provider": "anthropic", "model": "claude-opus-4-5",
     "output_limit": 70000, "max_tokens_per_call": 16000, "read_budget": 150000}
  ],
  "summarizer_model": "gpt-4o-mini",
  "context": {
    "recent_messages_kept": 8,
    "compact_slack": 4,
    "max_message_chars": 6000,
    "known_files_digest_chars": 3000
  },
  "tools": {
    "read_chunk_tokens": 100000,
    "max_file_bytes": 10000000,
    "web_search_max_results": 8
  },
  "changes": {"confirm_writes": true},
  "subagents": {
    "default_max": 4,
    "model": "gpt-4o-mini",
    "read_budget": 80000,
    "max_tokens_per_call": 4000,
    "max_debate_rounds": 3
  }
}
```

| Key | Meaning |
|-----|---------|
| `models[].name` | Display name and key for token accounting. Order = handoff order. |
| `models[].provider` | `anthropic` or `openai`. |
| `models[].model` | Provider model ID. |
| `models[].output_limit` | Cumulative output tokens per conversation before handoff. |
| `models[].max_tokens_per_call` | Output cap for a single API call (separate from `output_limit`; GPT-4o-mini cannot exceed about 16k). |
| `models[].read_budget` | Max tokens `read_file` may return per user turn, across parallel calls. |
| `summarizer_model` | Model name (from `models`) used to write summaries. Falls back to the active model. |
| `context.*` | How much history stays verbatim and how big the summaries and file digest can be. |
| `tools.read_chunk_tokens` | Tokens per `read_file` call. Lower it if 100k is too heavy for your use. |
| `changes.confirm_writes` | Show a diff and ask before every file write/edit (default `true`). |
| `subagents.default_max` | Default cap on sub-agents per batch; override per conversation with `/subagents N`. |
| `subagents.model` | Model name (from `models`) for sub-agents and debaters. |
| `subagents.read_budget` | Tokens each sub-agent may read in total. |
| `subagents.max_tokens_per_call` | Output cap per sub-agent/debater call. |
| `subagents.max_debate_rounds` | Upper limit on debate rounds. |

## MCP servers: `mcp_json.json`

Same shape as Claude Desktop and VS Code configs:

```json
{
  "mcpServers": {
    "time": {"command": "uvx", "args": ["mcp-server-time"]},
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "${PROJECT_ROOT}"]
    },
    "remote": {
      "url": "https://example.com/mcp",
      "headers": {"Authorization": "Bearer ${MY_TOKEN}"},
      "allowed_tools": ["search"]
    }
  }
}
```

- `command` means a stdio server; `url` means a streamable-HTTP server.
- Optional per server: `env`, `headers`, `allowed_tools`, `"disabled": true`.
- `${PROJECT_ROOT}` expands to the open folder (or the app folder in just-chat mode); `${VAR}` expands from the environment.
- Servers connect when you open a project or start chat. A server that fails to start is reported and skipped.
- The shipped examples are all `"disabled": true`; remove that line to enable one.

## Skills: `skills/`

Each subfolder with a `SKILL.md` is discovered as a skill:

```
skills/
└── my-skill/
    ├── SKILL.md          # YAML frontmatter (name, description) + instructions
    └── references/       # optional extra files the agent can read on demand
```

The agent sees only skill names and descriptions until a request matches, then loads the full instructions. Loading skills and reading skill resources run without a confirmation prompt; script execution is not enabled in this app. See the [Agent Skills docs](https://learn.microsoft.com/en-us/agent-framework/agents/skills) for the format.

## Troubleshooting

| Symptom | Likely cause |
|---------|--------------|
| "No API keys found" | `.env` missing or empty. Copy `.env.example` and fill it in. |
| A model is listed under "Skipped" | Its provider key is not set. |
| `ImportError` for the Anthropic or OpenAI client | Reinstall with `pip install -r requirements.txt`; the `agent-framework` meta-package includes both. |
| Token counts show 0 | The provider response had no usage details. Check your `agent-framework` version. |
| MCP server "failed to start" | Check the command exists (`uvx`, `npx`) and the config entry. |
| Web search fails | `ddgs` is rate-limited or offline; retry, or swap `_search()` in `tools/web_search.py` for another provider. |
| No `<< tool ok` lines, spinner stays on "waiting for <tool>" until text appears | Your version doesn't yield `function_result` items while streaming; harmless, only the status display is affected. |
| Streaming shows no token counts | Usage wasn't aggregated on the final streamed response; check `get_final_response().usage_details` on your version. |
| Something breaks only on 1.18.0 | The code was written against the 1.x docs (latest seen: 1.22). Check the client import, the `allow_multiple_tool_calls` option, `usage_details` key names, and the streaming content types (`text`, `function_call`, `function_result`) first. |

## Known limitations

- Pressing Ctrl+C during a turn exits the app; the interrupted turn is not saved.
- Decision checkpoints and "push back on flaws" are prompt-driven; the diff approval on writes is the only hard gate.
- Sub-agents are read-only and debaters have no tools; there is no write-capable sub-agent.
- There is no automatic failover on API errors or rate limits; handoff happens only on the token limit or `/handoff`.
- Only user and assistant text is kept between turns; intermediate tool calls and results are not replayed (file notes cover that need).
- `web_search` returns snippets only; there is no page-fetching tool yet.
