"""propose_decision - the agent's way of asking you before it commits to something big.

It renders options with pros/cons plus a recommendation, and you can pick one, suggest your
own approach, ask to discuss, or stop. The tool result tells the model to critique your
answer BEFORE acting, which is what makes it push back on flawed choices instead of obeying.
"""
from __future__ import annotations

from typing import Annotated

from agent_framework import tool
from pydantic import BaseModel, Field


class Option(BaseModel):
    label: str = Field(description="Short name of the option")
    description: str = Field(description="What choosing this means, 1-2 sentences")
    pros: list[str] = Field(default_factory=list, description="Key advantages")
    cons: list[str] = Field(default_factory=list, description="Key drawbacks or risks")


def _as_option(o) -> Option:
    return o if isinstance(o, Option) else Option(**o)


def _remember(ctx, line: str) -> None:
    conv = getattr(ctx, "conv", None)
    if conv is not None:
        conv.decisions.append(line[:220])
        del conv.decisions[:-15]            # keep the log short


def build_tools(ctx) -> list:
    @tool(approval_mode="never_require")
    async def propose_decision(
        title: Annotated[str, Field(description="The decision in a few words.")],
        context: Annotated[str, Field(description="Why this needs deciding; what you found. Brief.")],
        options: Annotated[list[Option], Field(description="2-4 genuinely different options.")],
        recommendation: Annotated[str, Field(description="Which option you recommend and why, in one or two sentences.")],
        risks: Annotated[str, Field(description="Main risks/flaws to keep in mind, if any.")] = "",
    ) -> str:
        """Ask the user to decide before you commit to any MAJOR decision (architecture or approach
        choices, new/removed dependencies, interface or schema changes, deleting/overwriting code,
        anything hard to undo). Ask one decision at a time and never call this in parallel with
        other tools."""
        if ctx.ui is None:
            return "No interactive UI. State your assumption clearly and proceed cautiously."
        opts = [_as_option(o) for o in options]
        ans = await ctx.ui.ask_decision(title, context, opts, recommendation, risks)
        kind = ans["type"]
        if kind == "choice":
            _remember(ctx, f"{title}: user chose '{ans['label']}'")
            return (f"USER CHOSE option {ans['index']}: {ans['label']}. Before acting, sanity-check it "
                    "against what you know (bugs, security, scalability, conflicts with the project or "
                    "earlier decisions). If it has a real flaw, explain it plainly and call "
                    "propose_decision again before doing anything. Otherwise proceed.")
        if kind == "custom":
            _remember(ctx, f"{title}: user suggested '{ans['text'][:120]}' (pending your review)")
            return (f"USER SUGGESTED THEIR OWN APPROACH: \"{ans['text']}\". Do not just accept it: "
                    "critique it honestly against the options and the project. If it has flaws, explain "
                    "them and call propose_decision again (include the user's idea as an option, with its "
                    "risks). If it is sound, say so briefly and proceed.")
        if kind == "discuss":
            return (f"USER WANTS TO DISCUSS before deciding: \"{ans['text']}\". Answer directly and "
                    "concisely, then call propose_decision again with refined options.")
        _remember(ctx, f"{title}: user said STOP")
        return ("USER SAYS STOP. Do not proceed with this decision or any related change. "
                "Ask what they would like instead.")

    return [propose_decision]
