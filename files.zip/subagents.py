"""Sub-agents and debate. Both need YOUR approval every time, and both respect your cap.

spawn_subagents  (project mode)  read-only workers that explore disjoint parts of the project
                                 in parallel and keep writing the per-file .md notes.
start_debate     (both modes)    debaters each argue one position for a few rounds, then a judge
                                 gives a verdict. Advice only - the main agent must still take the
                                 outcome to you via propose_decision.

Your cap (/subagents N, default from config) is the maximum number of sub-agents in one batch;
0 disables them. The real work happens in Engine.run_subagents / Engine.run_debate.
"""
from __future__ import annotations

from typing import Annotated

from agent_framework import tool
from pydantic import BaseModel, Field

from tools._paths import resolve_in_project


class SubTask(BaseModel):
    name: str = Field(description="Short label, e.g. 'api-layer'")
    instructions: str = Field(description="What this sub-agent must find out or document")
    paths: list[str] = Field(description="Files/folders it owns (relative to project root). "
                                         "Must not overlap other sub-agents.")


def _as_task(t) -> SubTask:
    return t if isinstance(t, SubTask) else SubTask(**t)


def build_tools(ctx) -> list:
    tools = []

    @tool(approval_mode="never_require")
    async def start_debate(
        topic: Annotated[str, Field(description="The question to settle, stated neutrally.")],
        context: Annotated[str, Field(description="All facts the debaters need (they cannot read files). Keep it compact.")],
        positions: Annotated[list[str], Field(description="2-3 distinct positions, one debater each.")],
        rounds: Annotated[int, Field(description="Debate rounds (1-3).", ge=1, le=3)] = 2,
    ) -> str:
        """Run a debate between sub-agents to settle a contested technical choice. Requires user
        approval. The verdict is advice: present the outcome to the user with propose_decision."""
        eng, conv = ctx.engine, ctx.conv
        if eng is None or ctx.ui is None:
            return "Debate is unavailable in this session."
        cap = eng.max_subagents(conv)
        if cap <= 0:
            return "Sub-agents/debate are disabled (the user set the maximum to 0)."
        if not 2 <= len(positions) <= 3:
            return "Error: provide 2 or 3 positions."
        if len(positions) > cap:
            return (f"Refused: the user's limit is {cap} sub-agents per batch but this debate needs "
                    f"{len(positions)}. Use fewer positions or decide without a debate.")
        spec = eng.subagent_spec(conv)
        if spec is None:
            return "All models have reached their output-token limit."
        rounds = min(rounds, eng.sub_cfg["max_debate_rounds"])
        calls = len(positions) * rounds + 1
        ok, note = await ctx.ui.confirm_debate(topic, positions, rounds, spec.name, calls)
        if not ok:
            return f"The user DECLINED the debate. Note: {note or '(none)'}. Continue without it."
        res = await eng.run_debate(conv, topic, context, positions, rounds)
        last = "\n".join(f"- {p}: {a[:600]}" for p, a in zip(positions, res["rounds"][-1]))
        return (f"DEBATE VERDICT (advisory):\n{res['verdict']}\n\nFinal-round arguments:\n{last}\n\n"
                "Now take this to the user with propose_decision; do not act on it yet.")

    tools.append(start_debate)

    if ctx.project_root is not None:
        @tool(approval_mode="never_require")
        async def spawn_subagents(
            purpose: Annotated[str, Field(description="Why sub-agents are worth it here, one sentence.")],
            tasks: Annotated[list[SubTask], Field(description="One entry per sub-agent, with disjoint paths.")],
        ) -> str:
            """Spawn read-only sub-agents that explore different parts of the project in parallel and
            write .md notes for each file. Use only for broad exploration, not small jobs. Requires
            user approval, and the user's cap limits how many you may spawn per batch."""
            eng, conv = ctx.engine, ctx.conv
            if eng is None or ctx.ui is None:
                return "Sub-agents are unavailable in this session."
            cap = eng.max_subagents(conv)
            if cap <= 0:
                return "Sub-agents are disabled (the user set the maximum to 0). Do the work yourself."
            jobs = [_as_task(t) for t in tasks]
            if not jobs:
                return "Error: no tasks given."
            if len(jobs) > cap:
                return (f"Refused: the user's limit is {cap} sub-agents per batch, you asked for "
                        f"{len(jobs)}. Re-plan with at most {cap} (give each one more files).")
            for j in jobs:
                for pth in j.paths:
                    try:
                        resolve_in_project(ctx, pth)
                    except ValueError as e:
                        return f"Error in task '{j.name}': {pth}: {e}"
            spec = eng.subagent_spec(conv)
            if spec is None:
                return "All models have reached their output-token limit."
            k, note = await ctx.ui.confirm_subagents(
                purpose, [(j.name, j.instructions, j.paths) for j in jobs], spec.name, cap)
            if k <= 0:
                return f"The user DECLINED sub-agents. Note: {note or '(none)'}. Continue without them."
            results = await eng.run_subagents(
                conv, [{"name": j.name, "instructions": j.instructions, "paths": j.paths}
                       for j in jobs[:k]])
            body = "\n\n".join(f"### sub:{r['name']} ({'ok' if r['ok'] else 'FAILED'})\n{r['text'][:1800]}"
                               for r in results)
            return (f"{body}\n\nFile notes were written to .agent_context/file_notes. Synthesize the "
                    "findings; use propose_decision for any decision that follows.")

        tools.append(spawn_subagents)
    return tools
