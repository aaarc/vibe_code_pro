"""All terminal interaction that happens *during* an agent turn lives here.

Why a class: during a turn we may be (a) streaming markdown, (b) showing a spinner
("waiting for web_search..."), or (c) asking you a question from inside a tool. Rich allows
only one live display at a time and prompts clash with live displays, so everything goes
through this object, which stops/restarts the right display around each prompt.

Interactive prompts (decisions, change approvals, sub-agent/debate approvals) take a lock, so
if the model fires several in parallel you answer them one at a time.
"""
from __future__ import annotations

import asyncio

from rich.console import Console, Group
from rich.live import Live
from rich.markdown import Markdown
from rich.markup import escape
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text


class UI:
    def __init__(self, console: Console):
        self.c = console
        self._live: Live | None = None
        self._status = None
        self._status_msg = ""
        self._buf = ""
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------ live display
    def spinner(self, msg: str) -> None:
        self._status_msg = msg
        self.end_text()
        if self._status is None:
            self._status = self.c.status(f"[dim]{escape(msg)}[/]")
            self._status.start()
        else:
            self._status.update(f"[dim]{escape(msg)}[/]")

    def stop_spinner(self) -> None:
        if self._status is not None:
            self._status.stop()
            self._status = None
        self._status_msg = ""

    def text(self, delta: str) -> None:
        """Append streamed model text; rendered live as markdown."""
        if self._status is not None:
            self._status.stop()
            self._status = None
            self._status_msg = ""
        self._buf += delta
        if self._live is None:
            self._live = Live(Markdown(self._buf), console=self.c, refresh_per_second=8,
                              vertical_overflow="visible")
            self._live.start()
        else:
            self._live.update(Markdown(self._buf))

    def end_text(self) -> None:
        if self._live is not None:
            self._live.update(Markdown(self._buf))
            self._live.stop()
            self._live = None
        self._buf = ""

    def event(self, msg: str) -> None:
        """Print one status line (markup allowed). Safe while a spinner is running."""
        self.end_text()
        self.c.print(msg)

    def show(self, renderable) -> None:
        self.end_text()
        self.c.print(renderable)

    def reset(self) -> None:
        self.end_text()
        self.stop_spinner()

    async def prompt(self, text: str) -> str:
        """Ask a question; pauses live displays and restores the spinner afterwards."""
        msg = self._status_msg
        self.end_text()
        if self._status is not None:
            self._status.stop()
            self._status = None
        try:
            return (await asyncio.to_thread(self.c.input, text)).strip()
        finally:
            if msg:
                self.spinner(msg)

    # ------------------------------------------------------------ 1) decisions
    async def ask_decision(self, title: str, context: str, options: list, recommendation: str,
                           risks: str) -> dict:
        async with self._lock:
            tbl = Table(show_lines=True, expand=True)
            tbl.add_column("#", width=3)
            tbl.add_column("Option", ratio=3)
            tbl.add_column("Pros", ratio=2)
            tbl.add_column("Cons", ratio=2)
            for i, o in enumerate(options, 1):
                tbl.add_row(
                    str(i),
                    f"[bold]{escape(o.label)}[/]\n{escape(o.description)}",
                    "\n".join("+ " + escape(p) for p in o.pros) or "-",
                    "\n".join("- " + escape(c) for c in o.cons) or "-")
            parts = []
            if context:
                parts.append(Text(context))
            parts.append(tbl)
            if recommendation:
                parts.append(Text.from_markup(f"[bold green]Recommended:[/] {escape(recommendation)}"))
            if risks:
                parts.append(Text.from_markup(f"[bold red]Risks:[/] {escape(risks)}"))
            self.show(Panel(Group(*parts), title=f"Decision needed: {escape(title)}",
                            border_style="yellow"))
            hint = (f"Pick 1-{len(options)}, c = your own approach, d = discuss / ask a question, "
                    f"s = stop  > ")
            while True:
                raw = await self.prompt(hint)
                low = raw.lower()
                if low.isdigit() and 1 <= int(low) <= len(options):
                    o = options[int(low) - 1]
                    return {"type": "choice", "index": int(low), "label": o.label}
                if low == "c":
                    t = await self.prompt("Your approach > ")
                    if t:
                        return {"type": "custom", "text": t}
                elif low == "d":
                    t = await self.prompt("Your question / comment > ")
                    if t:
                        return {"type": "discuss", "text": t}
                elif low == "s":
                    return {"type": "stop"}
                elif raw:
                    return {"type": "custom", "text": raw}

    # ------------------------------------------------------------ 3) change approval
    async def confirm_change(self, rel: str, summary: str, diff: str, is_new: bool,
                             affected: list[str]) -> tuple[bool, str]:
        async with self._lock:
            parts = [Text(summary)]
            if affected:
                parts.append(Text("Directly affected: " + ", ".join(affected), style="dim"))
            parts.append(Syntax(diff, "diff", theme="ansi_dark", word_wrap=True))
            self.show(Panel(Group(*parts), title=("New file: " if is_new else "Edit: ") + escape(rel),
                            border_style="magenta"))
            ans = (await self.prompt("Apply this change? (y)es / (n)o  > ")).lower()
            if ans in ("y", "yes"):
                return True, ""
            note = await self.prompt("Optional - tell the agent why, or what to do instead  > ")
            return False, note

    # ------------------------------------------------------------ 2) sub-agents / debate
    async def confirm_subagents(self, purpose: str, tasks: list[tuple], model: str,
                                cap: int) -> tuple[int, str]:
        """Returns (how_many_to_run, note). 0 means declined."""
        async with self._lock:
            tbl = Table(show_lines=True, expand=True)
            tbl.add_column("#", width=3)
            tbl.add_column("Sub-agent")
            tbl.add_column("Scope")
            tbl.add_column("Job", ratio=2)
            for i, (name, instr, paths) in enumerate(tasks, 1):
                tbl.add_row(str(i), escape(name), escape(", ".join(paths)), escape(instr[:160]))
            self.show(Panel(
                Group(Text(purpose), tbl,
                      Text(f"Model: {model} | running in parallel | your cap: {cap} per batch | "
                           f"read-only (they cannot change files)", style="dim")),
                title=f"Spawn {len(tasks)} sub-agent(s)?", border_style="cyan"))
            ans = (await self.prompt(
                f"(y)es / (n)o / a number 1-{len(tasks)} to run only the first N  > ")).lower()
            if ans in ("y", "yes"):
                return len(tasks), ""
            if ans.isdigit() and 1 <= int(ans) <= len(tasks):
                return int(ans), ""
            note = await self.prompt("Optional - tell the agent what to do instead  > ")
            return 0, note

    async def confirm_debate(self, topic: str, positions: list[str], rounds: int, model: str,
                             calls: int) -> tuple[bool, str]:
        async with self._lock:
            body = Group(
                Text(topic),
                Text("\n".join(f"  {i}. {p}" for i, p in enumerate(positions, 1))),
                Text(f"{len(positions)} debaters x {rounds} round(s) + 1 judge = {calls} model calls "
                     f"on {model}. Debaters can't read files or change anything.", style="dim"))
            self.show(Panel(body, title="Start a debate between sub-agents?", border_style="cyan"))
            ans = (await self.prompt("(y)es / (n)o  > ")).lower()
            if ans in ("y", "yes"):
                return True, ""
            return False, await self.prompt("Optional - tell the agent what to do instead  > ")
