#!/usr/bin/env python3
"""Entry point:  python main.py

Main menu -> open a project folder (state in <folder>/.agent_context)
          -> or just chat           (state in ./.agent_context next to this file)
Then pick / name / create conversations and chat. Type /help in a chat.
Replies stream live with tool-call status; the agent asks you before major decisions.
"""
from __future__ import annotations

import asyncio
import json
import sys
from contextlib import AsyncExitStack
from pathlib import Path

from dotenv import load_dotenv
from rich.console import Console
from rich.markdown import Markdown
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table

from agent_core.engine import AllModelsExhausted, Engine
from agent_core.mcp import connect_mcp
from agent_core.store import ContextStore, Conversation
from agent_core.ui import UI
from tools import load_tools
from tools._context import ToolContext

BASE = Path(__file__).resolve().parent
RECENT_FILE = BASE / ".agent_context" / "recent_projects.json"
console = Console()

HELP = """[bold]Commands[/]
/new [name]      start a new conversation in this folder
/rename <name>   rename this conversation
/switch          back to the conversation list
/tokens          token usage per model
/handoff         manually hand off to the next model
/subagents [n]   show / set the max sub-agents per batch (0 = disabled)
/changes         show the tail of major_changes.md
/menu            back to the main menu
/quit            exit"""


async def ask(prompt: str) -> str:
    return (await asyncio.to_thread(console.input, prompt)).strip()


# ----------------------------------------------------------------- helpers
def load_recent() -> list[str]:
    try:
        return json.loads(RECENT_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []


def remember_project(path: Path) -> None:
    items = [p for p in load_recent() if p != str(path)]
    items.insert(0, str(path))
    RECENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    RECENT_FILE.write_text(json.dumps(items[:8], indent=2), encoding="utf-8")


def make_skills_provider():
    skills_dir = BASE / "skills"
    skills_dir.mkdir(exist_ok=True)
    if not any(skills_dir.glob("*/SKILL.md")):
        return None
    try:
        from agent_framework import SkillsProvider
        return SkillsProvider.from_paths(
            skill_paths=str(skills_dir),
            disable_load_skill_approval=True,
            disable_read_skill_resource_approval=True,
        )
    except Exception as e:  # noqa: BLE001
        console.print(f"[yellow]Skills disabled: {escape(str(e))}[/]")
        return None


def token_line(engine: Engine, conv: Conversation, tin=None, tout=None) -> str:
    parts = []
    if tin is not None:
        parts.append(f"turn in {tin:,} / out {tout:,}")
    for s in engine.specs:
        used = conv.out_used(s.name)
        flag = " (retired)" if s.name in conv.retired or used >= s.output_limit else ""
        parts.append(f"{s.name} {used:,}/{s.output_limit:,} out{flag}")
    ti, to = conv.totals()
    parts.append(f"total in {ti:,} / out {to:,}")
    return " | ".join(parts)


def show_resume(conv: Conversation) -> None:
    body = conv.summary or "(no summary yet)"
    console.print(Panel(Markdown(body), title=f"Resuming: {conv.name}", border_style="cyan"))
    for t in conv.turns[-2:]:
        who = "you" if t["role"] == "user" else "assistant"
        console.print(f"[dim]{who}:[/] {escape(t['text'][:300])}")


# ----------------------------------------------------------------- menus
async def pick_conversation(store: ContextStore, label: str) -> Conversation | None:
    while True:
        convs = store.list()
        if not convs:
            name = await ask("No conversations yet. Name this one (Enter to skip): ")
            return store.create(name or None)
        table = Table(title=f"Conversations - {label}")
        for col in ("#", "Name", "Last updated", "Msgs", "Out tokens"):
            table.add_column(col)
        for i, c in enumerate(convs, 1):
            table.add_row(str(i), c.name, c.updated.replace("T", " "),
                          str(c.message_count), f"{c.totals()[1]:,}")
        console.print(table)
        console.print("number = open | n = new | r<N> = rename | d<N> = delete | b = back")
        ch = (await ask("> ")).lower()
        if ch == "b":
            return None
        if ch == "n":
            return store.create((await ask("Name (Enter to skip): ")) or None)
        if ch.isdigit() and 1 <= int(ch) <= len(convs):
            return convs[int(ch) - 1]
        if ch and ch[0] in "rd" and ch[1:].isdigit() and 1 <= int(ch[1:]) <= len(convs):
            target = convs[int(ch[1:]) - 1]
            if ch[0] == "r":
                store.rename(target, await ask("New name: "))
            elif (await ask(f"Delete '{target.name}'? type yes: ")).lower() == "yes":
                store.delete(target)
            continue
        console.print("[yellow]Not understood.[/]")


async def chat_loop(engine: Engine, store: ContextStore, conv: Conversation) -> str:
    show_resume(conv)
    console.print("[dim]Type /help for commands.[/]")
    while True:
        text = await ask("\n[bold green]you[/] > ")
        if not text:
            continue
        if text.startswith("/"):
            cmd, _, arg = text[1:].partition(" ")
            cmd, arg = cmd.lower(), arg.strip()
            if cmd in ("quit", "exit", "q"):
                return "quit"
            if cmd in ("switch", "conversations"):
                return "switch"
            if cmd == "menu":
                return "menu"
            if cmd == "help":
                console.print(HELP)
            elif cmd == "tokens":
                console.print(token_line(engine, conv))
            elif cmd == "rename":
                store.rename(conv, arg or await ask("New name: "))
                console.print(f"[dim]Renamed to '{conv.name}'.[/]")
            elif cmd == "new":
                conv = store.create(arg or (await ask("Name (Enter to skip): ")) or None)
                console.print(f"[dim]Started '{conv.name}'.[/]")
            elif cmd == "subagents":
                if arg.isdigit():
                    conv.max_subagents = int(arg)
                    store.save(conv)
                elif arg:
                    console.print("[yellow]Usage: /subagents <number>[/]")
                console.print(f"Max sub-agents per batch: [bold]{engine.max_subagents(conv)}[/] "
                              "(each batch still needs your approval; 0 = disabled)")
            elif cmd == "changes":
                log = store.dir / "major_changes.md"
                if log.exists():
                    console.print(Markdown(log.read_text(encoding="utf-8")[-3500:]))
                else:
                    console.print("[dim]No changes logged yet.[/]")
            elif cmd == "handoff":
                with console.status("Summarising and handing off..."):
                    res = await engine.force_handoff(conv)
                console.print(f"[yellow]Handoff: {res[0]} -> {res[1]}[/]" if res
                              else "[yellow]No other model available.[/]")
            else:
                console.print("[yellow]Unknown command. /help[/]")
            continue

        try:
            res = await engine.send(conv, text)
        except AllModelsExhausted:
            console.print(Panel(
                "Every model has hit its output-token limit for this conversation.\n"
                "Use /new for a fresh conversation (file notes in .agent_context are kept).",
                style="red"))
            continue
        except Exception as e:  # noqa: BLE001
            console.print(f"[red]Error:[/] {escape(str(e))}")
            continue

        if res.handoff:
            console.print(Panel(f"Output limit reached on {res.handoff[0]}. Context summarised; "
                                f"continuing on {res.handoff[1]}.", style="yellow"))
        console.print(f"[dim]{token_line(engine, conv, res.tokens_in, res.tokens_out)}[/]")


async def run_session(cfg: dict, project_root: Path | None) -> str:
    root = project_root or BASE
    label = str(project_root) if project_root else "just chat"
    store = ContextStore(root)
    ui = UI(console)
    tool_ctx = ToolContext(config=cfg, context_dir=store.dir, project_root=project_root, ui=ui)
    local_tools = load_tools(tool_ctx)

    async with AsyncExitStack() as stack:
        mcp_tools = await connect_mcp(stack, BASE / "mcp_json.json", console, root)
        try:
            engine = Engine(cfg, store, tool_ctx, local_tools + mcp_tools,
                            make_skills_provider(), project_root, ui)
        except RuntimeError as e:
            console.print(f"[red]{e}[/]")
            return "menu"
        if engine.skipped:
            console.print(f"[yellow]Skipped (no API key): {', '.join(engine.skipped)}[/]")
        console.print(f"[dim]Chain: {' -> '.join(s.name for s in engine.specs)} | "
                      f"tools: {len(local_tools) + len(mcp_tools)} loaded | "
                      f"file changes need approval: {cfg.get('changes', {}).get('confirm_writes', True)}[/]")

        while True:
            conv = await pick_conversation(store, label)
            if conv is None:
                return "menu"
            outcome = await chat_loop(engine, store, conv)
            if outcome in ("quit", "menu"):
                return outcome


async def main() -> None:
    load_dotenv(BASE / ".env")
    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    while True:
        console.print(Panel("[bold]MAF Agent[/]\n1) Open a project folder\n2) Just chat\nq) Quit",
                           border_style="blue"))
        choice = (await ask("> ")).lower()
        if choice in ("q", "quit"):
            return
        if choice == "2":
            outcome = await run_session(cfg, None)
        elif choice == "1":
            recent = load_recent()
            for i, r in enumerate(recent, 1):
                console.print(f"  {i}) {r}")
            raw = await ask("Folder path (or number from the list): ")
            if raw.isdigit() and 1 <= int(raw) <= len(recent):
                raw = recent[int(raw) - 1]
            path = Path(raw.strip('"').strip("'")).expanduser().resolve()
            if not path.is_dir():
                console.print("[red]That is not a folder.[/]")
                continue
            remember_project(path)
            outcome = await run_session(cfg, path)
        else:
            continue
        if outcome == "quit":
            return


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, EOFError):
        console.print("\nBye.")
        sys.exit(0)
