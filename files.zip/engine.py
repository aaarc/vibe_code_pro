"""Chat engine: model chain + handoff, token accounting, streaming, sub-agents, debate.

Terminal output goes through `UI` (agent_core/ui.py); nothing here calls print() directly.

Handoff rule
------------
Output tokens are counted per model, per conversation. The active model is the first model
in config order that is not retired and still under its `output_limit` (70k). After a turn
pushes a model over its limit the engine summarises the conversation, writes a handoff note,
and the next turn runs on the next model. A reply can't be cut off mid-flight, so a model can
overshoot slightly; the check happens between turns. Sub-agent and summariser tokens count
toward the model that produced them.
"""
from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field, replace
from typing import Callable

from agent_framework import Agent, Message
from rich.markdown import Markdown
from rich.markup import escape
from rich.panel import Panel

from agent_core.store import ContextStore, Conversation, _now

KEY_ENV = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY"}

DEFAULT_SUB = {"default_max": 4, "model": "gpt-4o-mini", "read_budget": 80_000,
               "max_tokens_per_call": 4_000, "max_debate_rounds": 3}

BASE_PROMPT = """You are a capable, concise assistant.
- When several independent lookups or tool calls are needed, issue them together in ONE step so they run in parallel.
- Prefer short, direct answers. Don't ask what you can find out yourself by reading the project.
- You may be continuing work started by a different model; rely on the summary, decisions and notes you are given."""

DECISION_PROMPT = """DECISION PROTOCOL (important - follow it strictly):
- A MAJOR decision is anything that shapes the work or is hard to undo: choosing between approaches or architectures, adding/removing dependencies, changing public interfaces, data formats or schemas, deleting or overwriting substantial code, or any open question with several reasonable answers.
- Before acting on a major decision, call propose_decision with 2-4 real options, their pros and cons, and your recommendation. Ask ONE decision at a time and never call propose_decision in parallel with other tools. Then act on the answer.
- Do NOT simply obey. Check the user's choice or suggestion for flaws (bugs, security, scalability, maintainability, conflicts with existing code or earlier decisions). If you find a real problem, say so plainly, explain why, and call propose_decision again (your fix / their original approach with the risk acknowledged / other) BEFORE proceeding. If they still choose a flawed path after being informed, you may proceed, but state the risk in the change log.
- Minor choices (local naming, formatting, reading files) need no question - just proceed."""

PROJECT_PROMPT = """Project folder: {root}
- Explore with list_directory; read files ONE per call with read_file (large files come in chunks).
- After reading a file, call save_file_note with a <=120-word summary so it need not be re-read later.
- Files under 'Known files' already have notes; read_file returns the cached note for those.
- Change files ONLY with write_file / edit_file. Each call needs change_summary, affected (files/processes directly affected) and reason; the user approves a diff and the change is appended to major_changes.md automatically. For changes made any other way (e.g. an MCP tool), call log_change.
- Do not make unrelated changes."""

SUBAGENT_PROMPT = """SUB-AGENTS AND DEBATE:
- For broad exploration of many files/modules you may call spawn_subagents, giving each sub-agent a disjoint set of paths. The user approves every batch and has set a cap of {cap} per batch. Do not spawn for small jobs. Sub-agents only read files and write notes; they cannot change anything.
- For a genuinely contested choice you may propose start_debate (also needs approval). A debate is advice only: afterwards present the result to the user with propose_decision."""

DEBATE_ONLY_PROMPT = """DEBATE: for a genuinely contested choice you may propose start_debate (needs user approval, user cap {cap} debaters). It is advice only: afterwards present the result with propose_decision."""

SUB_INSTRUCTIONS = """You are a focused, READ-ONLY exploration sub-agent working for a lead agent.
- Work only inside the paths you are given. Use list_directory, then read_file ONE file per call.
- After each file, call save_file_note with a <=120-word summary (purpose, key parts, dependencies, gotchas).
- Never guess about code you have not read. Be efficient; skip generated or vendored files.
- Finish with: (1) key findings in <=150 words, (2) the list of files you covered."""

DEBATER_INSTRUCTIONS = """You are a sharp, honest debater in a technical debate. You argue ONE assigned position as strongly as the facts allow, but you never invent facts, and in later rounds you concede points the other side genuinely wins. Stay under 150 words."""

JUDGE_INSTRUCTIONS = """You are a neutral technical judge. Read the debate and answer in <=200 words with: Verdict (a position or a synthesis), Deciding factors, Remaining risks, What to verify before committing."""


class AllModelsExhausted(Exception):
    pass


@dataclass
class ModelSpec:
    name: str
    provider: str
    model: str
    output_limit: int = 70_000
    max_tokens_per_call: int = 8_000
    read_budget: int = 100_000


@dataclass
class TurnResult:
    text: str
    model: str
    tokens_in: int
    tokens_out: int
    tools_used: list = field(default_factory=list)
    handoff: tuple | None = None


@dataclass
class Hooks:
    """Callbacks fired while a response streams. All optional."""
    text: Callable[[str], None] | None = None
    tool_start: Callable[[str, list], None] | None = None          # name, names still pending
    tool_done: Callable[[str, float, bool, list], None] | None = None  # name, secs, ok, pending


def _make_client(spec: ModelSpec):
    if spec.provider == "anthropic":
        try:
            from agent_framework.anthropic import AnthropicClient
        except ImportError:  # older layout
            from agent_framework_anthropic import AnthropicClient
        return AnthropicClient(model=spec.model)
    if spec.provider == "openai":
        from agent_framework.openai import OpenAIChatClient
        return OpenAIChatClient(model=spec.model)
    raise ValueError(f"Unknown provider: {spec.provider}")


def _usage(resp) -> tuple[int, int]:
    u = getattr(resp, "usage_details", None) or {}
    return int(u.get("input_token_count") or 0), int(u.get("output_token_count") or 0)


async def stream_run(agent, messages, hooks: Hooks | None = None):
    """Run an agent with streaming; fire hooks for text and tool-call start/finish.

    Returns (text, tokens_in, tokens_out, tool_names_called).
    Tool calls in one model step run in parallel inside the framework; we see N function_call
    items, then N function_result items.
    """
    hooks = hooks or Hooks()
    stream = agent.run(messages, stream=True)
    seen: set = set()
    pending: dict = {}            # call_id -> (name, started_at)
    called: list = []
    streamed: list = []
    async for update in stream:
        for c in getattr(update, "contents", None) or []:
            kind = getattr(c, "type", None)
            if kind == "text":
                if c.text:
                    streamed.append(c.text)
                    if hooks.text:
                        hooks.text(c.text)
            elif kind == "function_call":
                cid, name = getattr(c, "call_id", None), getattr(c, "name", None)
                if cid and name and cid not in seen:      # later chunks of the same call are ignored
                    seen.add(cid)
                    pending[cid] = (name, time.monotonic())
                    called.append(name)
                    if hooks.tool_start:
                        hooks.tool_start(name, [n for n, _ in pending.values()])
            elif kind == "function_result":
                cid = getattr(c, "call_id", None)
                if cid in pending:
                    name, t0 = pending.pop(cid)
                    ok = not getattr(c, "exception", None)
                    if hooks.tool_done:
                        hooks.tool_done(name, time.monotonic() - t0, ok,
                                        [n for n, _ in pending.values()])
    final = await stream.get_final_response()
    tin, tout = _usage(final)
    text = (getattr(final, "text", "") or "".join(streamed)).strip()
    return text, tin, tout, called


class Engine:
    def __init__(self, cfg: dict, store: ContextStore, tool_ctx, tools: list,
                 skills_provider, project_root, ui):
        self.cfg, self.store, self.tool_ctx = cfg, store, tool_ctx
        self.tools, self.skills, self.project_root, self.ui = tools, skills_provider, project_root, ui
        self.sub_cfg = {**DEFAULT_SUB, **cfg.get("subagents", {})}
        all_specs = [ModelSpec(**m) for m in cfg["models"]]
        self.specs = [s for s in all_specs if os.environ.get(KEY_ENV.get(s.provider, ""))]
        self.skipped = [s.name for s in all_specs if s not in self.specs]
        if not self.specs:
            raise RuntimeError("No API keys found. Copy .env.example to .env and add at least one key.")
        self._clients: dict = {}
        tool_ctx.ui, tool_ctx.engine = ui, self

    # ---- model selection -------------------------------------------------
    def _client(self, spec: ModelSpec):
        if spec.name not in self._clients:
            self._clients[spec.name] = _make_client(spec)
        return self._clients[spec.name]

    def _available(self, conv: Conversation, spec: ModelSpec) -> bool:
        return spec.name not in conv.retired and conv.out_used(spec.name) < spec.output_limit

    def current_spec(self, conv: Conversation) -> ModelSpec | None:
        return next((s for s in self.specs if self._available(conv, s)), None)

    def subagent_spec(self, conv: Conversation) -> ModelSpec | None:
        """Cheap model for sub-agents/debate if it still has budget, else the active model."""
        want = self.sub_cfg.get("model")
        for s in self.specs:
            if s.name == want and self._available(conv, s):
                return s
        return self.current_spec(conv)

    def max_subagents(self, conv: Conversation) -> int:
        v = conv.max_subagents
        return int(self.sub_cfg["default_max"] if v is None else v)

    async def force_handoff(self, conv: Conversation, reason: str = "manual") -> tuple | None:
        cur = self.current_spec(conv)
        if cur is None:
            return None
        conv.retired.append(cur.name)
        nxt = self.current_spec(conv)
        if nxt is None:
            conv.retired.remove(cur.name)  # nothing to hand off to
            return None
        result = self._record_handoff(conv, cur, nxt, reason)
        await self._compact(conv, force=True)
        self.store.save(conv)
        return result

    def _record_handoff(self, conv, frm: ModelSpec, to: ModelSpec, reason: str) -> tuple:
        conv.handoffs.append({"from": frm.name, "to": to.name, "at": _now(), "reason": reason,
                              "out_tokens": conv.out_used(frm.name)})
        conv.handoff_note = (f"HANDOFF: you are taking over from {frm.name} ({reason}). "
                             "Continue seamlessly using the summary, decisions and recent messages; "
                             "do not re-introduce yourself or redo finished work.")
        return (frm.name, to.name)

    def _agent(self, spec: ModelSpec, name: str, instructions: str, tools=None,
               max_tokens: int | None = None, skills: bool = False) -> Agent:
        kwargs = dict(
            client=self._client(spec), name=name, instructions=instructions,
            default_options={"max_tokens": max_tokens or spec.max_tokens_per_call,
                             "allow_multiple_tool_calls": True})
        if tools:
            kwargs["tools"] = tools
        if skills and self.skills is not None:
            kwargs["context_providers"] = [self.skills]
        return Agent(**kwargs)

    # ---- one streamed turn --------------------------------------------------
    async def send(self, conv: Conversation, user_text: str) -> TurnResult:
        spec = self.current_spec(conv)
        if spec is None:
            raise AllModelsExhausted()
        ctx, ui = self.tool_ctx, self.ui
        ctx.reset_turn_budget(spec.read_budget)
        ctx.conv, ctx.model_name = conv, spec.name

        messages = [Message(t["role"], [t["text"]]) for t in conv.turns]
        messages.append(Message("user", [user_text]))
        agent = self._agent(spec, "assistant", self._instructions(conv),
                            tools=self.tools or None, skills=True)

        waiting_model = f"waiting for {spec.name}..."

        def on_start(name: str, pending: list) -> None:
            ui.event(f"[cyan]>> calling[/] [bold]{escape(name)}[/]")
            ui.spinner("waiting for " + ", ".join(pending) + "...")

        def on_done(name: str, secs: float, ok: bool, pending: list) -> None:
            mark = "[green]ok[/]" if ok else "[red]failed[/]"
            ui.event(f"[dim]<< {escape(name)}[/] {mark} [dim]({secs:.1f}s)[/]")
            ui.spinner("waiting for " + ", ".join(pending) + "..." if pending else waiting_model)

        ui.event(f"\n[bold green]assistant[/] [dim]({spec.name})[/]")
        ui.spinner(waiting_model)
        try:
            text, tin, tout, tools_used = await stream_run(
                agent, messages, Hooks(text=ui.text, tool_start=on_start, tool_done=on_done))
        finally:
            ui.reset()

        conv.add_usage(spec.name, tin, tout)
        conv.handoff_note = ""                  # delivered
        self._append_turns(conv, spec.name, user_text, text)

        handoff = None
        nxt = self.current_spec(conv)
        if nxt is not None and nxt.name != spec.name:
            handoff = self._record_handoff(
                conv, spec, nxt, f"reached {spec.output_limit:,} output tokens")
        await self._compact(conv, force=handoff is not None)
        self.store.save(conv)
        return TurnResult(text, spec.name, tin, tout, tools_used, handoff)

    # ---- sub-agents -------------------------------------------------------------
    async def run_subagents(self, conv: Conversation, jobs: list[dict]) -> list[dict]:
        """Run read-only sub-agents in parallel (already approved by the user)."""
        from tools.file_reader import build_tools as read_tools   # local import: avoid cycle

        spec = self.subagent_spec(conv)
        if spec is None:
            raise AllModelsExhausted()
        ui, sc = self.ui, self.sub_cfg
        sem = asyncio.Semaphore(max(1, self.max_subagents(conv)))
        ui.event(f"[magenta]Starting {len(jobs)} sub-agent(s) on {spec.name}...[/]")

        async def one(job: dict) -> dict:
            label = job["name"]
            async with sem:
                sub_ctx = replace(self.tool_ctx, read_budget_per_turn=sc["read_budget"],
                                  read_budget_left=sc["read_budget"], label=label)
                agent = self._agent(spec, f"sub-{label}", SUB_INSTRUCTIONS,
                                    tools=read_tools(sub_ctx), max_tokens=sc["max_tokens_per_call"])
                prompt = (f"Task: {job['instructions']}\nYour paths: {', '.join(job['paths'])}\n"
                          "Stay inside these paths. You cannot modify files.")
                ui.event(f"[magenta]sub:{escape(label)} started[/]")
                t0 = time.monotonic()
                try:
                    text, tin, tout, called = await stream_run(agent, [Message("user", [prompt])])
                    conv.add_usage(spec.name, tin, tout)
                    ui.event(f"[magenta]sub:{escape(label)} done[/] [dim]({len(called)} tool calls, "
                             f"{tout:,} out tokens, {time.monotonic() - t0:.0f}s)[/]")
                    return {"name": label, "ok": True, "text": text}
                except Exception as e:  # noqa: BLE001
                    ui.event(f"[red]sub:{escape(label)} failed: {escape(str(e))}[/]")
                    return {"name": label, "ok": False, "text": f"FAILED: {e}"}

        results = await asyncio.gather(*(one(j) for j in jobs))
        ui.event("[magenta]Sub-agents finished.[/]")
        return list(results)

    # ---- debate -------------------------------------------------------------------
    async def run_debate(self, conv: Conversation, topic: str, context: str,
                         positions: list[str], rounds: int) -> dict:
        spec = self.subagent_spec(conv)
        if spec is None:
            raise AllModelsExhausted()
        ui, mt = self.ui, self.sub_cfg["max_tokens_per_call"]
        history: list[list[str]] = []

        async def ask(name: str, instructions: str, prompt: str) -> str:
            resp = await self._agent(spec, name, instructions, max_tokens=mt).run(prompt)
            tin, tout = _usage(resp)
            conv.add_usage(spec.name, tin, tout)
            return (getattr(resp, "text", "") or "").strip()

        for rnd in range(1, rounds + 1):
            ui.spinner(f"debate round {rnd}/{rounds}: {len(positions)} debaters arguing in parallel...")
            prev = ""
            if history:
                prev = "\n\nLast round:\n" + "\n".join(
                    f"[{p}] {a}" for p, a in zip(positions, history[-1]))

            def prompt_for(p: str) -> str:
                task = ("Make your strongest case." if rnd == 1 else
                        "Rebut the strongest opposing points and concede what is valid.")
                return (f"Topic: {topic}\nFacts: {context}\nYour position: {p}\n"
                        f"Round {rnd} of {rounds}. {task}{prev}")

            args = await asyncio.gather(*(
                ask(f"debater-{i + 1}", DEBATER_INSTRUCTIONS, prompt_for(p))
                for i, p in enumerate(positions)))
            history.append(list(args))
            ui.show(Panel(
                Markdown("\n\n".join(f"**{p}**\n\n{a}" for p, a in zip(positions, args))),
                title=f"Debate - round {rnd}", border_style="magenta"))

        ui.spinner("judge is deciding...")
        transcript = "\n\n".join(
            f"Round {i}:\n" + "\n".join(f"[{p}] {a}" for p, a in zip(positions, rd))
            for i, rd in enumerate(history, 1))
        verdict = await ask("judge", JUDGE_INSTRUCTIONS,
                            f"Topic: {topic}\nFacts: {context}\n\n{transcript}")
        ui.show(Panel(Markdown(verdict), title="Judge's verdict (advisory)", border_style="magenta"))
        return {"verdict": verdict, "rounds": history}

    # ---- context building -------------------------------------------------
    def _instructions(self, conv: Conversation) -> str:
        cap = self.max_subagents(conv)
        parts = [BASE_PROMPT, DECISION_PROMPT]
        if self.project_root is not None:
            parts.append(PROJECT_PROMPT.format(root=self.project_root))
            digest = self.store.known_files_digest(self.cfg["context"]["known_files_digest_chars"])
            if digest:
                parts.append("Known files:\n" + digest)
        if cap > 0:
            tpl = SUBAGENT_PROMPT if self.project_root is not None else DEBATE_ONLY_PROMPT
            parts.append(tpl.format(cap=cap))
        else:
            parts.append("Sub-agents and debate are DISABLED by the user. Do all work yourself.")
        if conv.decisions:
            parts.append("Decisions made so far in this conversation:\n" +
                         "\n".join(f"- {d}" for d in conv.decisions))
        if conv.summary:
            parts.append("Summary of the conversation so far:\n" + conv.summary)
        if conv.handoff_note:
            parts.append(conv.handoff_note)
        return "\n\n".join(parts)

    def _append_turns(self, conv, model: str, user_text: str, reply: str) -> None:
        limit = self.cfg["context"]["max_message_chars"]
        clip = lambda s: s if len(s) <= limit else s[:limit] + " ...[truncated]"  # noqa: E731
        now = _now()
        conv.turns.append({"role": "user", "text": clip(user_text), "ts": now, "model": None})
        conv.turns.append({"role": "assistant", "text": clip(reply or "(no text)"), "ts": now, "model": model})
        conv.message_count += 2

    # ---- summarisation ----------------------------------------------------
    async def _compact(self, conv: Conversation, force: bool = False) -> None:
        keep = self.cfg["context"]["recent_messages_kept"]
        slack = self.cfg["context"]["compact_slack"]
        if not force and len(conv.turns) <= keep + slack:
            return
        cut = len(conv.turns) - (2 if force else keep)
        if cut <= 0:
            return
        try:
            conv.summary = await self._summarize(conv, conv.turns[:cut])
            conv.turns = conv.turns[cut:]
        except Exception:  # noqa: BLE001 - keep full turns if summarising fails
            pass

    async def _summarize(self, conv: Conversation, old_turns: list) -> str:
        spec = next((s for s in self.specs if s.name == self.cfg.get("summarizer_model")), None) \
            or self.current_spec(conv) or self.specs[-1]
        transcript = "\n".join(f"{t['role'].upper()}: {t['text'][:1500]}" for t in old_turns)
        prompt = (f"Existing summary:\n{conv.summary or '(none)'}\n\nNew messages:\n{transcript}\n\n"
                  "Rewrite the summary in at most 250 words. Keep: goals, decisions, file paths, "
                  "open tasks, user preferences, facts learned. Drop pleasantries and anything resolved.")
        agent = self._agent(spec, "summarizer", "You write terse, factual conversation summaries.",
                            max_tokens=900)
        resp = await agent.run(prompt)
        tin, tout = _usage(resp)
        conv.add_usage(spec.name, tin, tout)    # summariser tokens count toward that model's usage
        return (getattr(resp, "text", "") or conv.summary).strip()
