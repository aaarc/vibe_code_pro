# docgen — architecture, flow and decisions

`docgen` turns a prompt (in any language) into a **DOCX and/or PDF** using the **Microsoft Agent
Framework (MAF)** for all LLM calls. It has three modes:

| mode | for | LLM calls | look |
|---|---|---|---|
| `simple` | plain documents | 1 | neutral: title, headings, paragraphs, bullets, bordered tables, header/footer |
| `long` | long-form, **≤ 14 pages** | 1 planner + N parallel section writers | cover/title page, clickable contents, numbered sections, modern tables, call-outs, header/footer rules |
| `visual` | visually rich | 1 planner + N parallel section writers | colour banner, contents chips, numbered section bands, stat tiles, card grids, step timelines, bar charts, call-outs, quotes, coloured header bar |

---

## 1. Quick start

```bash
pip install -r requirements.txt

export OPENAI_API_KEY=...                       # Windows PowerShell: $env:OPENAI_API_KEY="..."
python -m docgen "Quarterly sales report for a coffee chain" --mode visual --pages 5
python -m docgen "Un informe sobre energía solar" --mode long --pages 8 --format pdf
python -m docgen "تقرير عن الذكاء الاصطناعي في التعليم" --mode visual        # Arabic, RTL
python -m docgen "x" --provider mock --mode visual --lang ta                   # offline demo, no key
python -m unittest discover -s tests -v                                        # 13 tests, no key needed
```

Providers: `openai` (`OPENAI_API_KEY`), `azure` (`AZURE_OPENAI_ENDPOINT` + `AZURE_OPENAI_API_KEY`, or `az login`),
`anthropic` (`ANTHROPIC_API_KEY`), `mock` (offline). Anything else MAF supports: set
`DOCGEN_CLIENT_FACTORY="mypkg.mod:make_client"` (a function `model -> MAF chat client`).

Useful flags: `--lang xx` · `--pages N` · `--theme ocean|forest|sunset|royal|slate|rose` · `--page a4|letter` ·
`--model` / `--planner-model` · `--concurrency 6` · `--pdf-engine auto|reportlab|libreoffice` · `--format docx pdf` · `-v` (timings, tokens).
Env: `DOCGEN_FONT_DIR` (extra font folder).

> **Verification status (please read).** The renderers, parser, pipeline, concurrency, retry/fallback logic and
> multilingual paths were executed and visually checked (DOCX validated with an XSD validator; rendered through
> LibreOffice; PDFs inspected). The MAF calls themselves could **not** be run where this was built (no network, `agent-framework`
> not installable). They are isolated in `docgen/llm.py` (≈40 lines touch MAF) with defensive fallbacks for the
> known API variations; the tests drive that exact code with a fake MAF client. If your installed MAF version
> differs, `llm.py` is the only file to adjust (see decision D8).

---

## 2. The flow, top level

```
 user prompt ─┐
              ▼
 ┌──────────────────────────── cli.py ─────────────────────────────┐
 │ parse flags → Config → asyncio.run(pipeline.generate())          │
 └───────────────────────────────┬──────────────────────────────────┘
                                 ▼
 PHASE 0  setup           pipeline.generate: clamp pages (≤14 long/visual), create LLM wrapper
                                 │
        ┌────────────────────────┴───────────────────────┐
   mode = simple                                   mode = long | visual
        │                                                │
 PHASE 1a  WRITE (1 call)                       PHASE 1  PLAN  (1 small call, planner prompt)
   DocMark text with `# Title`                     lines: T / ST / LANG / TOC / THEME / S|title|brief|words|layout
        │                                                │  parse_plan() + normalise_words()  ← code fixes the word budget
        │                                         PHASE 2  WRITE  (N calls, asyncio.gather, semaphore-limited)
        │                                           one agent call per section, all at once;
        │                                           each sees: language, title, compact outline, its brief,
        │                                           its word budget, its layout hint
        │                                                │  a failed section → placeholder call-out, run continues
        ▼                                                ▼
 PHASE 3  PARSE + ASSEMBLE   docmark.parse_blocks() → IR dataclasses (ir.py); code injects numbered H2 headings
        │                    from the outline, strips duplicate headings, picks theme
        └────────────────────────┬───────────────────────┘
                                 ▼
 PHASE 4  ANALYSE   lang.detect_script(all text) → script, RTL?, CJK?, needs-shaping?   → fonts, engine choice
                                 ▼
 PHASE 5  RENDER    DOCX (python-docx)  ┐ built concurrently in threads
                    PDF  (reportlab)    ┘ …or DOCX → LibreOffice → PDF for scripts reportlab cannot shape
                                 ▼
 PHASE 6  REPORT    file paths, warnings, per-phase timings, LLM calls, tokens (when MAF reports usage)
```

### What each phase does and where

| phase | module | key points |
|---|---|---|
| 0 | `pipeline.py`, `llm.py` | `Config` → page clamp (`MAX_PAGES`), `LLM` wrapper with a global concurrency semaphore |
| 1 plan | `prompts.py`, `pipeline._plan` | planner returns ~150–250 tokens of line-based text; parsed leniently; one re-ask if unusable, then fallback to a single-call document |
| 2 write | `pipeline._write_sections` | `asyncio.gather` over one agent call per section; results come back in outline order; failures isolated per section |
| 3 parse | `docmark.py`, `ir.py` | DocMark (compact Markdown + `::: blocks`) → typed IR; forgiving parser |
| 4 analyse | `lang.py`, `fonts.py` | everything language-dependent is derived from the characters actually produced |
| 5 render | `render_docx.py`, `render_pdf.py` | both read the same IR + same theme → near-identical output |
| 6 report | `cli.py` | timings per phase; token counts from MAF `usage_details` when present |

### The DocMark dialect (what the LLM writes)

Standard Markdown (`##`, `###`, `**bold**`, `*italic*`, `` `code` ``, `-` bullets with 2-space nesting, `1.` lists, pipe tables) plus closed blocks:

```
::: tip|info|warning|success|danger|note  Title        ::: stats            ::: cards 3
text or bullets                                        42% | label           Card title
:::                                                    3.1x | label          text
::: steps                ::: bars Chart title          :::                    ---
Step title | sentence    Label | 72                                          Next card …
:::                      :::                                                 :::
::: quote Author
sentence
:::
```

---

## 3. Decisions and why

### D1 — The LLM writes *content in a compact Markdown dialect*, never layout, never JSON, never code
- **Tokens.** JSON costs ~25–30 % more output tokens (quotes, braces, key names) and, with structured output, adds a JSON-schema to every request. DocMark needs ~200 prompt tokens of syntax reminder and no schema.
- **Speed.** Fewer output tokens = proportionally lower latency (generation time is output-bound).
- **Robustness.** Markdown is the format models are best at. A malformed block degrades to text (unknown directive → note box, unclosed `:::` stops at the next block, loose lists tolerated) instead of failing a whole section the way an invalid JSON blob would.
- **Not "LLM writes python-docx code".** Slow, expensive, non-deterministic, a security risk (executing generated code), and it makes DOCX/PDF drift apart.

### D2 — One intermediate representation (IR), two deterministic renderers
`ir.py` (≈15 small dataclasses) is the contract. All design (colours, spacing, grids) is code, so output quality does not depend on the model's mood, layout changes need no re-prompting, and DOCX and PDF share one theme and one structure. Adding a block type = parser + IR + 2 renderer methods + one prompt line.

### D3 — Plan-then-fan-out (long / visual), single call (simple)
- **Why plan first?** Parallel writers cannot see each other. A tiny outline call gives them shared context (title, outline, their brief) so sections do not overlap and the document is coherent.
- **Why fan out?** Wall-clock ≈ planner + *slowest* section, instead of the sum of all sections. A 8-page document is roughly 2 short calls deep rather than ~8 long calls deep.
- **Why not one big call?** It is output-bound and serial (an 8-page document is ~5–6 k tokens ≈ a minute or more), cannot be parallelised, and risks truncation and drift.
- **Why simple mode has no planner?** One call is the fastest and cheapest possible path for a short plain document.
- **No review/"critic" pass.** Doubles latency and tokens for marginal gain. Quality is controlled by constraints (budgets, layouts) rather than by repair loops.

### D4 — `asyncio.gather` + semaphore, not MAF's `ConcurrentBuilder`
`ConcurrentBuilder` broadcasts the *same* input to every participant. Here every call has a *different* prompt (its own section), and we want per-section failure isolation, ordered results and a concurrency cap (provider rate limits). Plain `gather` over `agent.run()` does exactly that with less machinery. Agents are created per call and are **stateless** (no session/thread): there is no conversation to carry, and statelessness is what makes parallel calls safe.

### D5 — The layout is decided at *planning* time for visual mode
Independent writers will all happily choose "a callout and some cards". So the planner assigns each section a layout from `text, stats, cards, steps, bars, table, callout, quote`, with rules (neighbours differ, ≥4 distinct layouts, overview opens with stats/callout). That gives a designed visual rhythm *without* any cross-section communication or a second pass.

### D6 — Budgets are enforced by code, not trusted to the model
- The planner's per-section word counts are only **proportions**; `normalise_words()` rescales them to `pages × words-per-page` (380 long, 240 visual, 420 simple; visual is lower because boxes eat space), clamped per section.
- `pages` is clamped to 14 for long/visual ⇒ **always < 15 pages**. The PDF engine additionally re-renders with tighter type (×0.92, ×0.85) if the page count still exceeds the cap, and warns if it cannot comply.
- Sections are injected as `## N. Title` **by code** from the outline; writers are told not to emit the heading (saves tokens, guarantees numbering/TOC consistency; a stray H1/H2 is demoted).

### D7 — Token economy checklist (what is actually done)
1. DocMark instead of JSON; no schema in requests.
2. **Cache-friendly prompt order.** The system prompt (syntax spec) is first and identical for every call of a mode, and in section calls the *shared* user content (language, title, request, outline) precedes the section-specific lines, so all N parallel calls share one long prefix. Providers discount/accelerate repeated prefixes only above their minimum size (typically ~1024 tokens) — the syntax spec alone is smaller, so the benefit appears with longer requests/outlines (larger documents). It never hurts, and costs nothing.
3. Outline passed to writers is one line per section (title – brief), not the full plan.
4. The original request is truncated (1500 chars) in section calls.
5. No examples beyond one-line syntax reminders; no chain-of-thought or self-review instructions.
6. Document chrome is **language-neutral** — page numbers are `3 / 9`, dates are ISO — so no UI strings need translating. The only localised string, “Contents”, is returned by the planner for free (`TOC:` line).
7. Default model is a fast non-reasoning model (`gpt-4.1-mini`, `claude-haiku-5-5`). Reasoning models add hidden tokens/latency to every call; use `--planner-model` if you want a stronger model for just the cheap outline call.
8. Token usage is surfaced with `-v` (read from MAF `usage_details`) so you can measure instead of guess.

### D8 — MAF is confined to one module, with defensive adapters
`llm.py` is the only importer of `agent_framework`. It tries `client.as_agent(...)` then `create_agent(...)` then `Agent/ChatAgent(...)`; constructor kwargs `model` then `model_id`; reads `usage_details` as dict or object; retries transient errors with backoff but **not** auth errors; per-call timeout; `DOCGEN_CLIENT_FACTORY` escape hatch. Reason: MAF has been moving quickly (renames between previews and GA); the blast radius of any change must be one file, and the rest of the app must never see a provider type.

### D9 — python-docx + reportlab (not docx-js, WeasyPrint, or LibreOffice-only)
| option | verdict |
|---|---|
| python-docx + reportlab | **chosen**: pure Python wheels → identical install on Windows/Linux/macOS; fast (PDF ≈ 0.3 s); full control |
| docx-js | would need Node next to a Python app |
| WeasyPrint (HTML→PDF) | beautiful CSS, but needs Pango/GTK system libs — painful on Windows |
| LibreOffice only | needs a 300 MB install for every user, ~2 s start-up; but perfect shaping |

So LibreOffice is an **optional accelerator for hard scripts** (D12), not a requirement.

### D10 — DOCX craftsmanship (what is hand-tuned and why)
- **Every visual element is a real Word table** (call-outs, stat tiles, cards, steps, bars, banner, section bands). It stays editable and renders the same in Word, LibreOffice and Google Docs; text boxes/shapes do not.
- **Grids use spacer columns/rows, not white borders** → gaps stay transparent; works on any background.
- **Explicit `dxa` widths everywhere** + fixed layout (percent widths break in Google Docs).
- **`tblInd` = left cell margin**, otherwise Word's legacy table placement pushes tables past the margin.
- **Numbered lists restart**: each list gets its own `w:num` with `startOverride` (otherwise numbering continues across the whole document).
- **Schema order is respected** (`insert_element_before` with full successor lists) — the output passes the OOXML XSD validator; Word is strict about child order.
- **Run properties** always carry `rFonts` (ascii/hAnsi/eastAsia/cs), `szCs/bCs/iCs`, `w:rtl`, `w:lang` — what makes Arabic/Hebrew/Indic/CJK pick the right font and direction.
- **Contents in DOCX = static, hyperlinked list** (bookmarks + `w:hyperlink`), not a TOC *field*: a field needs "update fields" on open (Word shows a prompt; LibreOffice/Google Docs show blanks). Trade-off: no page numbers in the DOCX contents. The PDF contents has real page numbers.
- Nested empty-paragraph quirks (a cell must end with a paragraph; consecutive tables merge) are handled by a small `_Box` abstraction.
- Header/footer: `PAGE`/`NUMPAGES` fields, title + date, rules; page 1 has no header (banner/title block instead).

### D11 — PDF craftsmanship
- `reportlab.platypus` with the same visual vocabulary; contents via `multiBuild` (2 passes only when a TOC exists) giving clickable entries with page numbers; PDF **bookmarks/outline** for every section.
- "Page X / Y" via the deferred-canvas pattern, with header/footer drawn on the final pass.
- Rounded banner, tinted cards with accent edges, a custom bar-chart flowable (no matplotlib dependency, no images).
- Tables repeat their header row across pages and never split a row.

### D12 — Multilingual design
1. **Derived from characters, not from codes.** `detect_script()` counts the script of the finished text, so a wrong/missing language code, or mixed-language content, cannot break rendering.
2. **Fonts.** DOCX names per-script fonts (Word/LibreOffice substitute if absent). PDF searches `DOCGEN_FONT_DIR`, `./fonts`, then OS font folders (Windows/Linux/macOS) for TrueType families, falling back to reportlab's built-in CID fonts for CJK. Bold/italic variants are used when present. *Known reportlab limit:* CFF-flavoured OpenType (Noto Sans CJK `.otf/.ttc`) cannot be embedded — such files are skipped automatically.
3. **CJK line breaking:** reportlab's `wordWrap='CJK'`; parser joins wrapped lines without inserting spaces between CJK characters.
4. **RTL (Arabic/Hebrew):** DOCX gets paragraph `bidi`, run `rtl`, mirrored tables (`bidiVisual`) and mirrored accent borders. In reportlab (no shaping engine) the fallback reshapes + reorders **per wrapped line** (reordering a whole paragraph first makes multi-line RTL text come out upside-down) using the optional `arabic-reshaper` + `python-bidi`.
5. **Engine routing (`--pdf-engine auto`).** Scripts that need a shaping engine (Arabic, Hebrew, all Indic scripts, Thai, Khmer, Lao, Myanmar, Tibetan) or for which no suitable font is found go **DOCX → LibreOffice → PDF** when LibreOffice is installed (verified here with Arabic and Tamil); everything else uses the fast reportlab path. LibreOffice runs with a private temporary profile, so it never clashes with a running instance. If it is missing, you get a warning and a best-effort PDF; DOCX output is unaffected (Word shapes natively).
6. **Language-neutral chrome** (D7.6) avoids translation tables.

### D13 — Windows/Linux portability
`pathlib` everywhere; no shell invocations except LibreOffice via an argument list; OS-specific font folders and LibreOffice locations are data; UTF-8 explicit; output file names are Unicode-safe but strip Windows-illegal characters (`\/:*?"<>|`), trimmed to 60 chars; blocking renderers run through `asyncio.to_thread`; no Unix-only modules; only wheels with Windows builds.

### D14 — Failure behaviour (degrade, don't die)
Per-call timeout + retries with exponential backoff (not for 401/403); one failed section → warning call-out in that place + exit code 0 + a warning line; unusable plan → one re-ask → single-call fallback document; tolerant parser; missing fonts → warning, not crash; page cap exceeded → tighter re-render → warning.

### D15 — Colour system
Each theme is 3 hand-picked colours + a 4-colour palette; every tint (card/box backgrounds) and shade (text on tint) is **computed** (`tint()`, `shade()`), and text colour on solid fills is chosen by luminance (`on_color()`) so contrast stays readable on any palette (e.g. dark text on an orange badge). Call-out kinds use fixed semantic colours (info blue, tip teal, success green, warning amber, danger red). The planner picks the theme for visual mode; `--theme` overrides.

### D16 — Offline `mock` provider + tests
A canned DocMark generator in 5 languages (en, ar, zh, ja, ta) exercises the *entire* pipeline — including the concurrency fan-out, both renderers and font/RTL paths — with zero cost. `tests/test_docgen.py` also drives the real `LLM` class through a fake MAF client to assert: calls overlap, the concurrency cap holds, usage is accumulated, the section system prompt is byte-identical (cache-friendly), a failing section degrades, a bad plan falls back, and long documents stay < 15 pages.

---

## 4. Known limitations / honest notes
- **MAF integration unverified end-to-end here** (see §1). Expect at most a small tweak in `llm.py`.
- Latency/cost numbers in this document are structural expectations (call depth, output tokens), not measurements — run with `-v`.
- DOCX contents has no page numbers (D10). DOCX page count is not measured (the PDF engine measures and enforces; the DOCX uses the same word budget).
- Visual elements are drawn with tables/shapes; there are no raster images or matplotlib charts (bar charts only). Fits the "fast, light" goal; adding images would be a new block type (D2).
- reportlab RTL fallback: no inline bold/italic inside RTL paragraphs, no PDF contents list, no contents chips. The LibreOffice route has none of these limits and is chosen automatically when available.
- Indic/Thai/Khmer PDFs need LibreOffice (reportlab cannot shape them).
- CJK bold: system CJK TrueType families rarely ship a bold file; regular weight is reused.
- Possible future speed-up: stream the planner and start section writers as soon as each `S |` line arrives (saves a few seconds; costs complexity).
- Examples in `examples/` were generated by the **mock** provider (canned text) to show layout and multilingual rendering, not LLM quality.

## 5. Extending
- **New block** (e.g. timeline): add dataclass in `ir.py`, a `kind` branch in `docmark._directive`, `_b_<name>` in `render_docx.py`, `b_<name>` in `render_pdf.py`, a line in `prompts.VISUAL_EXT`.
- **New theme**: one line in `themes.THEMES`.
- **New script font**: add candidates in `fonts.CANDIDATES` / `lang.DOCX_FONTS`.
- **New provider**: `llm._build_client` branch or `DOCGEN_CLIENT_FACTORY`.

## 6. File map
```
docgen/cli.py        flags → Config → run            docgen/render_docx.py   IR → DOCX (python-docx + OOXML)
docgen/pipeline.py   phases, plan parsing, budgets   docgen/render_pdf.py    IR → PDF (reportlab) + LibreOffice bridge
docgen/llm.py        the only MAF touch-point        docgen/lang.py          script detection, DOCX font table
docgen/prompts.py    all prompts                     docgen/fonts.py         PDF font discovery (Win/Linux/macOS)
docgen/docmark.py    DocMark → IR parser             docgen/themes.py        palettes + colour maths
docgen/ir.py         IR dataclasses                  docgen/mock.py          offline provider
tests/test_docgen.py                                 examples/               sample outputs (mock text)
```
